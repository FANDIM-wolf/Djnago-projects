from django.contrib import admin
from .models import User,Accounting,Post

admin.site.register(User)
admin.site.register(Accounting)
admin.site.register(Post)
# Register your models here.
