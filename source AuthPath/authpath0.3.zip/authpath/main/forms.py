from django import forms
from .models import User


class UserForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ('name_of_user','possition_of_user','email_of_user','date_of_birth_of_user','main_photo','describtion_of_user',
        	'login_of_user','password_of_user','age_of_user')
