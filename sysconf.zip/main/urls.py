# posts/urls.py
from django.urls import path
 
from .views import HomePageView,CreatePostView 
 
urlpatterns = [
    path('', HomePageView.as_view(), name='home'), #it is class with request
    path('post/', CreatePostView.as_view(), name='add_post') # new
]