from .models import User,FileUpload
from django.forms import ModelForm ,TextInput
from django import forms
class UserForm(ModelForm):
	class Meta:
		model=User
		fields=["name_of_user","possition_of_user","age_of_user"]
		widgets ={"name_of_user":TextInput(attrs={
			'placholder':'Enter name '
			}),
		"possition_of_user":TextInput(attrs={
			'placholder':'Enter possition'
			}),
		"age_of_user":TextInput(attrs={
			'placholder':'Enter age '
			})
		},
class FileUploadForm(ModelForm):
	class Meta:
		model=FileUpload
		fields=["name_of_file","document_of_file"]

