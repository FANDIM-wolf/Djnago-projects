from django.apps import AppConfig


class NotebookConfig(AppConfig):
    name = 'notebook'
