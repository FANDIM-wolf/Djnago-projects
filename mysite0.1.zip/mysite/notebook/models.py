from django.db import models

class User(models.Model):
    name_of_user = models.CharField(max_length=200)
    possition_of_user = models.CharField(max_length=200)
  
    age_of_user=models.IntegerField()
    def __str__(self):
        return self.name_of_user
# Create your models here.
# model of file in data base
class FileUpload(models.Model):
	name_of_file = models.CharField(max_length=345)
	document_of_file = models.FileField(upload_to='uploads/')
	def __str__(self):
		return self.document_of_file
		
