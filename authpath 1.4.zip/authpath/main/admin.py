from django.contrib import admin
from .models import User,Accounting,Post,Authour

admin.site.register(User)
admin.site.register(Accounting)
admin.site.register(Post)
admin.site.register(Authour)

# Register your models here.
