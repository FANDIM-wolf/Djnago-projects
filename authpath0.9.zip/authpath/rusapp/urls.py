from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static

from . import views

urlpatterns = [
    path('',views.index, name="index"),
    path('tests/',views.log),
    path('addusers/',views.adduserindatabase, name="adduser"),
    path('tests/deletes/<int:pk>/',views.delete_user),
    path('tests/sessions/<int:pk>/',views.session_end),
    path('tests/post_communitys/<int:pk>',views.add_post_and_show_it,name="addpostandshowit"),
    path('tests/emailchecks',views.send_email_and_get_code),
    path('emailchecks/',views.send_email_and_get_code),
    path('emailchecks/password_codes/',views.password_code),
    path('emailchecks/password_codes/addusers/',views.adduserindatabase,name="adduser")
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)