from django.apps import AppConfig


class RusappConfig(AppConfig):
    name = 'rusapp'
